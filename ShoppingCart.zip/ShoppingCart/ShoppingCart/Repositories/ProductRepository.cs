﻿using Microsoft.EntityFrameworkCore;
using ShoppingCart.Data;
using ShoppingCart.Models;


namespace ShoppingCart.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ShoppingCartContext _context; 

        public ProductRepository(ShoppingCartContext context)
        {
            _context = context;
        }

        public Product GetProduct(string productCode)
        {
            //var product = (from p in _context.Products
            //where p.ProductCode == productCode
            //select p).FirstOrDefaultAsync();

            return _context.Products.FirstOrDefault(p => p.ProductCode == productCode);
        }

        public async Task<Product> AddProductAsync(Product product)
        {
            try
            {
                _context.Products.Add(product);
                await _context.SaveChangesAsync();
                return product;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return null;
        }

        public decimal GetTotalPrice(string productCode, int itemCount)
        {
            string[] productCodeArray = productCode.Split(",");
            decimal totalPrice = 0;

            //var totalPrice1 = productCodeArray
            //       .Select(item => GetProduct(item.Trim())) // Trim spaces
            //       .Where(product => product != null) // Filter out null products
            //       .Sum(product =>
            //       {
            //           decimal discount = GetDiscount(product.ProductCode, itemCount);
            //           // Adjust pricing logic
            //           decimal discountFactor = discount == 1 ? 0 : discount / 100;
            //           return (product.Price * itemCount) - (product.Price * itemCount * discountFactor);
            //       });

            foreach (var item in productCodeArray)
            {
                var product =  GetProduct(item);
                if (product != null)
                {
                    
                    totalPrice += (product.Price * itemCount) - (product.Price * itemCount * (GetDiscount(item, itemCount)==1?0: GetDiscount(item, itemCount) / 100)); // Adjust pricing logic as needed
                }
            }
            return totalPrice;
        }
        public decimal GetDiscount(string productCode, int count)
        {
            switch (productCode)
            {
                case "A1":
                    if (count >= 3)
                    {
                        return 25; // Discount for A1 if count is >= 2
                    }
                    return 1; // Default discount for A1

                case "3-Q":
                    return 1; // Discount for 3-Q

                case "45K11":
                    if (count >= 5)
                    {
                        return 25; // Discount for 45K11 if count is >= 5
                    }
                    return 1; // Default discount for 45K11

                case "X1":
                    return 1; // Discount for X1

                default:
                    return 1; // Default discount for unknown product codes
            }
        }

    }

}

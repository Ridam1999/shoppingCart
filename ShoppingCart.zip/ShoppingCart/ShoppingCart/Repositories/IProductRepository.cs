﻿using ShoppingCart.Models;

namespace ShoppingCart.Repositories
{
    //public class IProductRepository
    //{
    //}
    public interface IProductRepository
    {
        Task<Product> AddProductAsync(Product product); // Asynchronous method for adding a product
        decimal GetTotalPrice(string productCode, int itemCount); // For calculating total price
    }

}

﻿

USE[TestDB]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 19-10-2024 04:07:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
    [ProductID][int] IDENTITY(1, 1) NOT NULL,
    [ProductCode][varchar](10) NOT NULL,
    [ProductName][varchar](50) NOT NULL,
    [Price][decimal](10, 2) NOT NULL,
    [Discount][nvarchar](50) NULL,
PRIMARY KEY CLUSTERED
(
    [ProductID] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
) ON[PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Products] ON
GO
INSERT [dbo].[Products]([ProductID], [ProductCode], [ProductName], [Price], [Discount]) VALUES(1, N'A1', N'Phone', CAST(20000.00 AS Decimal(10, 2)), NULL)
GO
INSERT[dbo].[Products] ([ProductID], [ProductCode], [ProductName], [Price], [Discount]) VALUES(2, N'3-Q', N'Laptop', CAST(30000.00 AS Decimal(10, 2)), NULL)
GO
INSERT[dbo].[Products] ([ProductID], [ProductCode], [ProductName], [Price], [Discount]) VALUES(3, N'45K11', N'Samsung', CAST(40000.00 AS Decimal(10, 2)), NULL)
GO
INSERT[dbo].[Products] ([ProductID], [ProductCode], [ProductName], [Price], [Discount]) VALUES(4, N'X1', N'Lenovo', CAST(10000.00 AS Decimal(10, 2)), NULL)
GO
SET IDENTITY_INSERT [dbo].[Products] OFF
GO

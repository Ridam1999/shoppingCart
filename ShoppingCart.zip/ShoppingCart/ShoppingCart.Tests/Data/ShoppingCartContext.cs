﻿namespace ShoppingCart.Tests.Data
{
    public class ShoppingCartContext
    {
    }
}

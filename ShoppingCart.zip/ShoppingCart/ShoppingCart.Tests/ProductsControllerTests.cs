﻿using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using ShoppingCart.Models;
using ShoppingCart.Repositories;
using ShoppingCart.Controllers;

namespace ShoppingCart.Tests
{
    public class ProductsControllerTests
    {
        private readonly ProductsController _controller;
        private readonly Mock<IProductRepository> _mockRepo;

        public ProductsControllerTests()
        {
            _mockRepo = new Mock<IProductRepository>();
            _controller = new ProductsController(_mockRepo.Object);
        }

        [Fact]
        public async Task AddProduct_ReturnsCreatedResult_WhenProductIsValid()
        {
            // Arrange
            var product = new Product { ProductCode = "A1", ProductName = "Item A", Price = 2.00M };
            _mockRepo.Setup(repo => repo.AddProductAsync(product)).ReturnsAsync(product);

            // Act
            var result = await _controller.AddProduct(product);

            // Assert
            var createdResult = Assert.IsType<CreatedAtActionResult>(result);
            var returnProduct = Assert.IsType<Product>(createdResult.Value);
            Assert.Equal("A1", returnProduct.ProductCode);
        }

        [Fact]
        public async Task AddProduct_ReturnsBadRequest_WhenProductIsNull()
        {
            // Arrange
            Product product = null;

            // Act
            var result = await _controller.AddProduct(product);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Product is null.", badRequestResult.Value);
        }

        [Fact]
        public async Task AddProduct_Returns500StatusCode_WhenExceptionIsThrown()
        {
            // Arrange
            var product = new Product { ProductCode = "A1", ProductName = "Item A", Price = 2.00M };
            _mockRepo.Setup(repo => repo.AddProductAsync(product)).ThrowsAsync(new System.Exception("Database error"));

            // Act
            var result = await _controller.AddProduct(product);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusCodeResult.StatusCode);
            Assert.Equal("An error occurred while adding the product.", statusCodeResult.Value);
        }

        [Fact]
        public async Task GetProduct_ReturnsOkResult_WhenProductExists()
        {
            // Arrange
            var productCode = "A1";
            var itemCount = 2;
            var totalPrice = 4.00M; // Assuming this is the expected total price
            _mockRepo.Setup(repo => repo.GetTotalPrice(productCode, itemCount)).Returns(totalPrice);

            // Act
            var result = await _controller.GetProduct(productCode, itemCount);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(totalPrice, okResult.Value);
        }

        [Fact]
        public async Task GetProduct_ReturnsNotFoundResult_WhenProductDoesNotExist()
        {
            // Arrange
            var productCode = "Unknown";
            var itemCount = 1;
            _mockRepo.Setup(repo => repo.GetTotalPrice(productCode, itemCount)).Returns(0); // Assuming 0 means not found

            // Act
            var result = await _controller.GetProduct(productCode, itemCount);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(0, okResult.Value);
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repositories;

namespace ShoppingCart.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository _productRepository;

        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpPost("AddProduct")]
        public async Task<IActionResult> AddProduct([FromForm] Product product)
        {
            try
            {
                var createdProduct = await _productRepository.AddProductAsync(product);
                return CreatedAtAction(nameof(AddProduct), createdProduct);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost("GetProduct")]
        public async Task<IActionResult> GetProduct([FromForm] string productCode, int itemCount)
        {
            var totalPrice = _productRepository.GetTotalPrice(productCode, itemCount);
            return Ok(totalPrice);
        }
    }

}
